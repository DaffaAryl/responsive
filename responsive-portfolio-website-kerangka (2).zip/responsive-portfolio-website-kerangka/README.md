# Responsive Portfolio Website Jhon Doe

## [Watch it on youtube](https://youtu.be/6cidbUHNZRQ)

###  Responsive Portfolio Website
A clean and nice web portfolio for designer or developer. That includes almost everything you want to show. At first, your name and a great image. Then the About section displays more information about you. Then the list of skills it offers. It also has a section where it shows some recent work. And at the bottom it has contact information and a form, and at the bottom a footer.

Don't forget to join the channel for more videos like this.
[Bedimcode](https://www.youtube.com/c/Bedimcode)
